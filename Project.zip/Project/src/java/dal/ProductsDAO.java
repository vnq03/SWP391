/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Categories;
import model.Products;

/**
 *
 * @author ADMIN
 */
public class ProductsDAO extends DBContext {

    public List<Products> getAllProducts() {
        List<Products> list = new ArrayList<>();
        String sql = "select * from Products";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // đọc ra từng cột 1 trong bảng products(10 cột)
                //Có 2 cách -- c2: rs.getString("id") 
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public Products getProductById(String id) {
        String sql = "Select * from Products "
                + "where id=?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    //đọc từ bảng products theo cid
    public List<Products> getProductByCid(int cid) {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT [id]\n"
                + "      ,[name]\n"
                + "      ,[quantity]\n"
                + "      ,[price]\n"
                + "      ,[releaseDate]\n"
                + "      ,[describe]\n"
                + "      ,[image]\n"
                + "      ,[cid]\n"
                + "      ,[specifications]\n"
                + "      ,[reviews]\n"
                + "  FROM [dbo].[Products]"
                + "  where cid=?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            //set ? ban đầu là 1 
            //thằng nào mà có thêm điều kiện (?) đều phải có thằng set này
            st.setInt(1, cid);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Products> getProductByName(String name) {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT [id]\n"
                + "      ,[name]\n"
                + "      ,[quantity]\n"
                + "      ,[price]\n"
                + "      ,[releaseDate]\n"
                + "      ,[describe]\n"
                + "      ,[image]\n"
                + "      ,[cid]\n"
                + "      ,[specifications]\n"
                + "      ,[reviews]\n"
                + "  FROM [dbo].[Products]"
                + "  where [name] like ?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            //set ? ban đầu là 1 ( truyền cái name vào ? ý)
            //thằng nào mà có thêm điều kiện (?) đều phải có thằng set này
            st.setString(1, "%" + name + "%");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    //phân trang
    public List<Products> getListByPage(List<Products> list,
            int start, int end) {
        ArrayList<Products> arr = new ArrayList<>();
        for (int i = start; i < end; i++) {
            arr.add(list.get(i));
        }
        return arr;
    }

    public void deleteProductByID(String id) {
        String sql = "DELETE FROM [dbo].[Products]\n"
                + "      WHERE id=?;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, id);
            st.executeUpdate(); // ko có Resultset nữa vì hàm này ko trả về bất cứ cái gì cả
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void addProduct(String id, String name, int quantity, String releaseDate,
            String image, double price, String describe, String specifications, int cid) {
        List<Products> list = new ArrayList<>();
        String sql = "INSERT INTO [dbo].[Products]\n"
                + "           ([id]\n"
                + "           ,[name]\n"
                + "           ,[quantity]\n"
                + "	      ,[releaseDate]\n"
                + "	      ,[image]\n"
                + "           ,[price]\n"
                + "           ,[describe]\n"
                + "	      ,[specifications]\n"
                + "           ,[cid])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            //set ? ban đầu là 1 ( truyền cái name vào ? ý)
            //thằng nào mà có thêm điều kiện (?) đều phải có thằng set này
            st.setString(1, id);
            st.setString(2, name);
            st.setInt(3, quantity);
            st.setString(4, releaseDate);
            st.setString(5, image);
            st.setDouble(6, price);
            st.setString(7, describe);
            st.setString(8, specifications);
            st.setInt(9, cid);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void editProduct(String id, String name, int quantity, String releaseDate,
            String image, double price, String describe, String specifications, int cid) {
        List<Products> list = new ArrayList<>();
        String sql = "UPDATE [dbo].[Products]\n"
                + "   SET [id] = ?\n"
                + "      ,[name] = ?\n"
                + "      ,[quantity] = ?\n"
                + "	 ,[releaseDate] = ?\n"
                + "	 ,[image] = ?\n"
                + "      ,[price] = ?\n"
                + "      ,[describe] = ?\n"
                + "      ,[specifications] = ?\n"
                + "	 ,[cid] = ?\n"
                + " WHERE id = ?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            //set ? ban đầu là 1 ( truyền cái name vào ? ý)
            //thằng nào mà có thêm điều kiện (?) đều phải có thằng set này
            st.setString(1, id);
            st.setString(2, name);
            st.setInt(3, quantity);
            st.setString(4, releaseDate);
            st.setString(5, image);
            st.setDouble(6, price);
            st.setString(7, describe);
            st.setString(8, specifications);
            st.setInt(9, cid);
            st.setString(10, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public List<Products> getSellingProducts() {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT TOP 8 [id], [name], [quantity], [price], [releaseDate], [describe], [image], [cid], [specifications], [reviews]\n"
                + "FROM [dbo].[Products]\n"
                + "ORDER BY [quantity] ASC;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // đọc ra từng cột 1 trong bảng products(10 cột)
                //Có 2 cách -- c2: rs.getString("id") 
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Products> getNewProducts() {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT TOP 8 [id], [name], [quantity], [price], [releaseDate], [describe], [image], [cid], [specifications], [reviews]\n"
                + "FROM [dbo].[Products]\n"
                + "ORDER BY [releaseDate] DESC;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // đọc ra từng cột 1 trong bảng products(10 cột)
                //Có 2 cách -- c2: rs.getString("id") 
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Products> sortProductDesc() {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT [id], [name], [quantity], [price], [releaseDate], [describe], [image], [cid], [specifications], [reviews]\n"
                + "FROM [dbo].[Products]\n"
                + "ORDER BY [price] DESC;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // đọc ra từng cột 1 trong bảng products(10 cột)
                //Có 2 cách -- c2: rs.getString("id") 
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    public List<Products> sortProductAsc() {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT [id], [name], [quantity], [price], [releaseDate], [describe], [image], [cid], [specifications], [reviews]\n"
                + "FROM [dbo].[Products]\n"
                + "ORDER BY [price] ASC;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                // đọc ra từng cột 1 trong bảng products(10 cột)
                //Có 2 cách -- c2: rs.getString("id") 
                Products p = new Products(rs.getString(1),
                        rs.getString(2),
                        rs.getInt(3),
                        rs.getDouble(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8),
                        rs.getString(9),
                        rs.getString(10)
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
}
