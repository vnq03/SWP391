/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.util.ArrayList;
import java.util.List;
import model.Cart;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ADMIN
 */
public class CartDAO extends DBContext {

    public List<Cart> getCartByEmail(String email) {
        List<Cart> list = new ArrayList();
        String sql = "SELECT [Product]\n"
                + "      ,[Price]\n"
                + "      ,[Quantity]\n"
                + "      ,[Total]\n"
                + "      ,[Img]\n"
                + "  FROM [dbo].[Cart]\n"
                + "  WHERE [Email] = ?;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, email);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Cart c = new Cart();
                c.setProduct(rs.getString("Product"));
                c.setPrice(rs.getDouble("Price"));
                c.setQuantity(rs.getInt("Quantity"));
                c.setTotal(rs.getDouble("Total"));
                c.setImg(rs.getString("Img"));
                list.add(c);
            }
        } catch (Exception e) {
        }

        return list;
    }

    public void insert(String product, double price, int quantity, double total, String img, String email) {
        String sql = "INSERT INTO [dbo].[Cart]\n"
                + "           ([Product]\n"
                + "           ,[Price]\n"
                + "           ,[Quantity]\n"
                + "           ,[Total]\n"
                + "           ,[Img])\n"
                + "           ,[Email])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?)";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, product);
            st.setDouble(2, price);
            st.setInt(3, quantity);
            st.setDouble(4, total);
            st.setString(5, img);
            st.setString(5, email);
            st.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void delete(String pro) {
        String sql = "DELETE FROM [dbo].[Cart]\n"
                + "      WHERE Product=?";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, pro);
            st.executeUpdate();
        } catch (Exception e) {
        }

    }

}
