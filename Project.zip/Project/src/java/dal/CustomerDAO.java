/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Customer;
import model.Products;

/**
 *
 * @author ADMIN
 */
public class CustomerDAO extends DBContext {

    public Customer getCustomerByEmail(String email) {
        String sql = "SELECT \n"
                + "      ,[Gender]\n"
                + "      ,[DOB]\n"
                + "      ,[Phone]\n"
                + "      ,[Address]\n"
                + "  FROM [dbo].[Customer]\n"
                + "  WHERE Email = ?;";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            st.setString(1, email);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                return new Customer(rs.getString("Email"),
                        rs.getString("Gender"),
                        rs.getDate("DOB"),
                        rs.getString("Phone"),
                        rs.getString("Address"),
                        rs.getDouble("Wallet"));
            };
        } catch (SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    public void insertProfile(String email, String gender, String dob, String phone,
            String address, String wallet) {
        String sql = "INSERT INTO [dbo].[Customer]\n"
                + "           ([Email]\n"
                + "           ,[Gender]\n"
                + "           ,[DOB]\n"
                + "           ,[Phone]\n"
                + "           ,[Address]\n"
                + "           ,[Wallet])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?,?)";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            //set ? ban đầu là 1 ( truyền cái name vào ? ý)
            //thằng nào mà có thêm điều kiện (?) đều phải có thằng set này
            st.setString(1, email);
            st.setString(2, gender);
            st.setString(3, dob);
            st.setString(4, phone);
            st.setString(5, address);
            st.setString(6, wallet);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
