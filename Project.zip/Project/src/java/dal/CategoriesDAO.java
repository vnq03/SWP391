/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.util.ArrayList;
import java.util.List;
import model.Categories;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Products;
import org.apache.tomcat.dbcp.dbcp2.SQLExceptionList;

/**
 *
 * @author ADMIN
 */
public class CategoriesDAO extends DBContext {

    //doc tat ca, cac ban ghi tu table categories
    public List<Categories> getAll() {
        List<Categories> list = new ArrayList<>();
        String sql = "select * from Categories";
        try {
            // connection lấy từ DBContext
            PreparedStatement st = connection.prepareStatement(sql);
            //executeQuery là chỉ dùng cho lệnh select
            /*executeUpdate sẽ dùng cho các lệnh còn lại
                (update,insert into, remove...) 
             */
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                //lấy ra từng cột trong bảng categories
                Categories c = new Categories(rs.getInt("ID"), 
                                             rs.getString("name"));
                list.add(c);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

}
