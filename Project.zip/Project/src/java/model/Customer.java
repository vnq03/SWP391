/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class Customer {
    /*
    CREATE TABLE Customer(
	[Email] [varchar](50) references Account(Email),
	[Gender] [varchar](10),
	[DOB] [DATE],
	[Phone][varchar](20) primary key,
	[Address][nvarchar](50),
	[Wallet][money]

)
    */
    private String email;
    private String gender;
    private Date dob;
    private String phone;
    private String address;
    private double wallet;

    public Customer() {
    }

    public Customer(String email, String gender, Date dob, String phone, String address, double wallet) {
        this.email = email;
        this.gender = gender;
        this.dob = dob;
        this.phone = phone;
        this.address = address;
        this.wallet = wallet;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getWallet() {
        return wallet;
    }

    public void setWallet(double wallet) {
        this.wallet = wallet;
    }

    
   
    
    
    
}
